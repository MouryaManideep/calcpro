# CalcPro – Python Calculator Package

A beginner-friendly Python package for basic arithmetic operations.

## Features

- Addition
- Subtraction
- Multiplication

## Usage

```python
from calc import add, sub, mul
add(2, 3, 4......)
sub(5,4)
mul(5,4)
```
